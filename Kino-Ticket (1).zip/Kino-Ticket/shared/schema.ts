
import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===
export const reservations = pgTable("reservations", {
  id: serial("id").primaryKey(),
  movieTitle: text("movie_title").notNull(),
  ticketCount: integer("ticket_count").notNull(),
  pricePerTicket: integer("price_per_ticket").notNull(), // Stored in cents
  totalPrice: integer("total_price").notNull(), // Stored in cents
  discountApplied: boolean("discount_applied").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// === BASE SCHEMAS ===
export const insertReservationSchema = createInsertSchema(reservations).omit({ 
  id: true, 
  createdAt: true,
  totalPrice: true, // Calculated on backend
  discountApplied: true // Calculated on backend
}).extend({
  ticketCount: z.number().min(1, "Must reserve at least 1 ticket"),
  pricePerTicket: z.number().min(0, "Price cannot be negative"),
});

// === EXPLICIT API CONTRACT TYPES ===
export type Reservation = typeof reservations.$inferSelect;
export type InsertReservation = z.infer<typeof insertReservationSchema>;

// Request types
export type CreateReservationRequest = InsertReservation;

// Response types
export type ReservationResponse = Reservation;
export type ReservationListResponse = Reservation[];
