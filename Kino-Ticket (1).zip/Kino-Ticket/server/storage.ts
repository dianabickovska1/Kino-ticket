
import { db } from "./db";
import {
  reservations,
  type Reservation,
  type InsertReservation,
} from "@shared/schema";

export interface IStorage {
  getReservations(): Promise<Reservation[]>;
  createReservation(reservation: InsertReservation): Promise<Reservation>;
}

export class DatabaseStorage implements IStorage {
  async getReservations(): Promise<Reservation[]> {
    return await db.select().from(reservations).orderBy(reservations.createdAt);
  }

  async createReservation(insertReservation: InsertReservation): Promise<Reservation> {
    const { ticketCount, pricePerTicket } = insertReservation;
    
    // Calculate total price
    let totalPrice = ticketCount * pricePerTicket;
    let discountApplied = false;

    // Apply discount if 5 or more tickets (10% off)
    if (ticketCount >= 5) {
      totalPrice = Math.round(totalPrice * 0.9);
      discountApplied = true;
    }

    const [reservation] = await db
      .insert(reservations)
      .values({
        ...insertReservation,
        totalPrice,
        discountApplied,
      })
      .returning();

    return reservation;
  }
}

export const storage = new DatabaseStorage();
