
import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Get all reservations
  app.get(api.reservations.list.path, async (_req, res) => {
    const reservations = await storage.getReservations();
    res.json(reservations);
  });

  // Create a new reservation
  app.post(api.reservations.create.path, async (req, res) => {
    try {
      const input = api.reservations.create.input.parse(req.body);
      const reservation = await storage.createReservation(input);
      res.status(201).json(reservation);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: "Invalid input data",
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Seed data if empty
  const existing = await storage.getReservations();
  if (existing.length === 0) {
    console.log("Seeding database...");
    await storage.createReservation({
      movieTitle: "Avatar: The Way of Water",
      ticketCount: 2,
      pricePerTicket: 1200, // 12.00 EUR
    });
    await storage.createReservation({
      movieTitle: "Oppenheimer",
      ticketCount: 5,
      pricePerTicket: 1000, // 10.00 EUR - Should trigger discount
    });
    await storage.createReservation({
      movieTitle: "Barbie",
      ticketCount: 1,
      pricePerTicket: 850, // 8.50 EUR
    });
    console.log("Database seeded!");
  }

  return httpServer;
}
