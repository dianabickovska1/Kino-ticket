import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertReservationSchema, type CreateReservationRequest } from "@shared/schema";
import { useCreateReservation } from "@/hooks/use-reservations";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Ticket, Film, Calculator, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

export function ReservationForm() {
  const { toast } = useToast();
  const createReservation = useCreateReservation();
  
  // Default values
  const form = useForm<CreateReservationRequest>({
    resolver: zodResolver(insertReservationSchema),
    defaultValues: {
      movieTitle: "",
      ticketCount: 1,
      pricePerTicket: 850, // 8.50 EUR in cents
    },
  });

  // Watch values for live calculation
  const ticketCount = form.watch("ticketCount");
  const pricePerTicket = form.watch("pricePerTicket");
  
  // Calculate totals for preview
  const isDiscountEligible = ticketCount >= 5;
  const subtotal = ticketCount * pricePerTicket;
  const discountAmount = isDiscountEligible ? Math.round(subtotal * 0.1) : 0;
  const total = subtotal - discountAmount;

  const onSubmit = (data: CreateReservationRequest) => {
    createReservation.mutate(data, {
      onSuccess: () => {
        toast({
          title: "Rezervācija veiksmīga!",
          description: `Rezervētas ${data.ticketCount} biļetes uz filmu "${data.movieTitle}".`,
        });
        form.reset({
          movieTitle: "",
          ticketCount: 1,
          pricePerTicket: 850,
        });
      },
      onError: (error) => {
        toast({
          title: "Kļūda",
          description: error.message,
          variant: "destructive",
        });
      },
    });
  };

  return (
    <Card className="glass-card overflow-hidden border-primary/10">
      <CardHeader className="bg-gradient-to-r from-primary/10 to-transparent">
        <CardTitle className="flex items-center gap-2">
          <Ticket className="w-6 h-6 text-primary" />
          Jauna Rezervācija
        </CardTitle>
        <CardDescription>
          Izvēlieties filmu un biļešu skaitu. Atlaide 10% pērkot 5+ biļetes!
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="movieTitle"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2 text-primary-foreground/80">
                    <Film className="w-4 h-4" /> Filma
                  </FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Ievadiet filmas nosaukumu..." 
                      className="bg-secondary/50 border-white/10 text-lg"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="ticketCount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Biļešu skaits</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min={1}
                        className="bg-secondary/50 border-white/10 font-mono"
                        {...field}
                        onChange={e => field.onChange(e.target.valueAsNumber)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="pricePerTicket"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cena par biļeti (centi)</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input 
                          type="number" 
                          min={0}
                          className="bg-secondary/50 border-white/10 font-mono pr-12"
                          {...field}
                          onChange={e => field.onChange(e.target.valueAsNumber)}
                        />
                        <div className="absolute right-3 top-2.5 text-muted-foreground text-sm">
                          EUR {(field.value / 100).toFixed(2)}
                        </div>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Live Calculation Preview */}
            <div className="bg-secondary/30 rounded-lg p-4 space-y-2 border border-white/5">
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Summa ({ticketCount} x {(pricePerTicket / 100).toFixed(2)} €)</span>
                <span>{(subtotal / 100).toFixed(2)} €</span>
              </div>
              
              <AnimatePresence>
                {isDiscountEligible && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="flex justify-between text-sm text-primary font-medium overflow-hidden"
                  >
                    <span>Atlaide (10%)</span>
                    <span>-{(discountAmount / 100).toFixed(2)} €</span>
                  </motion.div>
                )}
              </AnimatePresence>
              
              <div className="pt-2 mt-2 border-t border-white/10 flex justify-between items-end">
                <span className="text-lg font-bold">Kopā apmaksai</span>
                <span className="text-3xl font-bold font-mono text-primary neon-glow">
                  {(total / 100).toFixed(2)} €
                </span>
              </div>
            </div>

            <Button 
              type="submit" 
              variant="premium" 
              className="w-full"
              disabled={createReservation.isPending}
            >
              {createReservation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Apstrādā...
                </>
              ) : (
                <>
                  <Calculator className="mr-2 h-4 w-4" />
                  Aprēķināt un Rezervēt
                </>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
