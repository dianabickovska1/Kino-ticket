import { useReservations } from "@/hooks/use-reservations";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { format } from "date-fns";
import { Ticket, Clock, Loader2, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

export function ReservationsList() {
  const { data: reservations, isLoading, isError } = useReservations();

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
        <Loader2 className="w-8 h-8 animate-spin mb-4 text-primary" />
        <p>Ielādē vēsturi...</p>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-destructive">
        <AlertCircle className="w-8 h-8 mb-4" />
        <p>Neizdevās ielādēt datus</p>
      </div>
    );
  }

  if (!reservations?.length) {
    return (
      <Card className="bg-secondary/20 border-dashed border-white/10">
        <CardContent className="flex flex-col items-center justify-center py-12 text-muted-foreground">
          <Ticket className="w-12 h-12 mb-4 opacity-20" />
          <p>Nav aktīvu rezervāciju</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold font-display text-foreground/90 mb-6 flex items-center gap-2">
        <Clock className="w-6 h-6 text-primary" />
        Rezervāciju Vēsture
      </h2>
      
      <div className="grid gap-4">
        {reservations.map((res, index) => (
          <motion.div
            key={res.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="hover:border-primary/30 transition-colors bg-card/50 backdrop-blur-sm">
              <CardContent className="flex items-center justify-between p-6">
                <div className="space-y-1">
                  <h3 className="font-bold text-lg text-foreground">{res.movieTitle}</h3>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Ticket className="w-4 h-4" /> {res.ticketCount} gab.
                    </span>
                    <span>•</span>
                    <span>{format(new Date(res.createdAt || new Date()), "dd.MM.yyyy HH:mm")}</span>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="text-2xl font-bold font-mono text-primary">
                    {(res.totalPrice / 100).toFixed(2)} €
                  </div>
                  {res.discountApplied && (
                    <Badge variant="secondary" className="bg-green-500/10 text-green-400 border-green-500/20">
                      10% Atlaide
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
