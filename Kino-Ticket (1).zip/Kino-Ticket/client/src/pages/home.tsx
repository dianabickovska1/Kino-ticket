import { ReservationForm } from "@/components/reservation-form";
import { ReservationsList } from "@/components/reservations-list";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="min-h-screen bg-background relative overflow-x-hidden">
      {/* Cinematic Background Elements */}
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-10 pointer-events-none" />
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/90 to-background pointer-events-none" />
      
      {/* Decorative Glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[128px] pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-[128px] pointer-events-none" />

      <main className="container mx-auto px-4 py-12 relative z-10 max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16 space-y-4"
        >
          <h1 className="text-5xl md:text-7xl font-display font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary via-white to-primary tracking-tight pb-2 text-shadow">
            KINO BIĻETES
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Ērta biļešu rezervācija un cenu aprēķins tiešsaistē.
            <span className="block mt-2 text-primary font-medium">
              Rezervē 5+ biļetes un saņem 10% atlaidi!
            </span>
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          <motion.div 
            className="lg:col-span-5 lg:sticky lg:top-8"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <ReservationForm />
          </motion.div>

          <motion.div 
            className="lg:col-span-7"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <ReservationsList />
          </motion.div>
        </div>
      </main>
      
      <footer className="py-8 text-center text-muted-foreground text-sm border-t border-white/5 bg-background/50 backdrop-blur-sm mt-12">
        <p>© 2024 Kino Biļetes. Visas tiesības aizsargātas.</p>
      </footer>
    </div>
  );
}
