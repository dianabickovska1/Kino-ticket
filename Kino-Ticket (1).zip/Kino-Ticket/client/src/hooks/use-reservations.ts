import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type CreateReservationInput, type ReservationResponse } from "@shared/routes";

// GET /api/reservations
export function useReservations() {
  return useQuery({
    queryKey: [api.reservations.list.path],
    queryFn: async () => {
      const res = await fetch(api.reservations.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Neizdevās ielādēt rezervācijas");
      return api.reservations.list.responses[200].parse(await res.json());
    },
  });
}

// POST /api/reservations
export function useCreateReservation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: CreateReservationInput) => {
      const res = await fetch(api.reservations.create.path, {
        method: api.reservations.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.reservations.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Neizdevās izveidot rezervāciju");
      }
      return api.reservations.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.reservations.list.path] });
    },
  });
}
