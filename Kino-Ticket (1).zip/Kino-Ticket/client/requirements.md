## Packages
framer-motion | Smooth animations for route transitions and interactive elements
lucide-react | Iconography for cinema theme
clsx | Utility for constructing class names conditionally
tailwind-merge | Utility for merging Tailwind classes efficiently

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Outfit', sans-serif"],
  body: ["'DM Sans', sans-serif"],
  mono: ["'Fira Code', monospace"],
}
